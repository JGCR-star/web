<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title></title>
</head>
<body>
<h2 align="center">Listado de Empleados</h2>
<table border="1" width="500" align="center">
<tr bgcolor="skyblue">
  <th colspan="6">Mantenimiento de Empleado</th>
  <th><a href="nuevo.php">Agregar</a></th>
</tr>
<tr bgcolor="skyblue">
  <th>Codigo</th><th>Nombre</th><th>Edad</th><th>Sexo</th>
  <th>Sueldo</th><th>Foto</th><th>Accion</th>
</tr>

<?php
$cnx = new PDO ("mysql:host=localhost;dbname=empleados","root","");
$res = $cnx-> query("select * from emple");
foreach ($res as $row){
  ?>
<tr>
  <td><?php echo $row[0]; ?> </td>
  <td><?php echo $row[1]; ?> </td>
  <td><?php echo $row[2]; ?> </td>
  <td><?php echo $row[3]; ?> </td>
  <td><?php echo $row[4]; ?> </td>
  <td><img src="fotos/ <?php echo $row[6]; ?>" width= "50" height ="40"></td>
  <td>Editar || Eliminar</td>
</tr>
  <?php
}
?>
</table>
</body>
</html>