<?
 session_start();
 session_destroy();
 ?>
 <html>
 <head>
 <title>Contenido no seguro</title>
 </head>
 <body>
 Ahora estás fuera de la aplicación segura.
 <br>
 <br>
 <a href="login.php">Autenticar usuario</a>
 </body>
 </html>