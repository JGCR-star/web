﻿# MySQL-Front 5.0  (Build 1.0)

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;


# Host: localhost    Database: empresa
# ------------------------------------------------------
# Server version 5.0.51b-community

DROP DATABASE IF EXISTS `empresa`;
CREATE DATABASE `empresa` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `empresa`;

#
# Table structure for table catalogo
#

CREATE TABLE `catalogo` (
  `id` int(11) NOT NULL auto_increment,
  `producto` varchar(100) default NULL,
  `precio` decimal(9,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
INSERT INTO `catalogo` VALUES (1,'Monitor',320);
INSERT INTO `catalogo` VALUES (2,'Teclado',20);
/*!40000 ALTER TABLE `catalogo` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table productos
#

CREATE TABLE `productos` (
  `idprod` int(11) NOT NULL auto_increment,
  `descripcion` varchar(255) default NULL,
  `marca` varchar(255) default NULL,
  `precio` decimal(10,2) default NULL,
  `stock` int(11) default NULL,
  `fechaing` date default NULL,
  PRIMARY KEY  (`idprod`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
INSERT INTO `productos` VALUES (1,'monitor','sansung',120,10,'2001-01-01');
INSERT INTO `productos` VALUES (2,'mouse','microsoft',35,25,'2001-01-01');
INSERT INTO `productos` VALUES (3,'teclado','genius',20,13,'2001-01-01');
INSERT INTO `productos` VALUES (4,'parlantes','lg',35,19,'2001-01-01');
INSERT INTO `productos` VALUES (5,'cpu','toshiba',450,20,'2001-01-01');
INSERT INTO `productos` VALUES (6,'audifonos','philips',25,15,'2001-01-01');
INSERT INTO `productos` VALUES (7,'bluetooth','sansung',10,20,'2001-01-01');
INSERT INTO `productos` VALUES (8,'estabilizador','delta power',55,35,'2001-01-01');
INSERT INTO `productos` VALUES (9,'camara web','genius',45,25,'2001-01-01');
INSERT INTO `productos` VALUES (10,'microfono','sansung',20,20,'2001-01-01');//
INSERT INTO `productos` VALUES (10,'audifonos','genius',15,20,'2001-01-01');
INSERT INTO `productos` VALUES (10,'mouse','chinaso',33,20,'2001-01-01');
INSERT INTO `productos` VALUES (10,'memoria extraible','samsung',250,20,'2001-01-01');
INSERT INTO `productos` VALUES (10,'usb','sansung',35,20,'2001-01-01');
INSERT INTO `productos` VALUES (10,'monitor','lenovo',150,20,'2001-01-01');
INSERT INTO `productos` VALUES (10,'lectora de disco','sansung',70,20,'2001-01-01');
INSERT INTO `productos` VALUES (10,'adaptador de cable HDMI','sansung',40,20,'2001-01-01');
INSERT INTO `productos` VALUES (10,'ventilador','sansung',35,20,'2001-01-01');
INSERT INTO `productos` VALUES (10,'cpu','sansung',200,20,'2001-01-01');
INSERT INTO `productos` VALUES (10,'tarjeta de video','Nvidia',150,20,'2001-01-01');

/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;

#
# Table structure for table usuarios
#

CREATE TABLE `usuarios` (
  `Id` int(11) NOT NULL auto_increment,
  `usuario` varchar(10) default NULL,
  `password` varchar(10) default NULL,
  `nivel` varchar(2) default NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
INSERT INTO `usuarios` VALUES (1,'jose','123456','1');
INSERT INTO `usuarios` VALUES (2,'cueva','123','2');
INSERT INTO `usuarios` VALUES (3,'isabel','123456','1');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
