<?php
$conex=new mysqli("localhost","root","","empresa")
?>