<?php
$usuario=$_REQUEST["usuario"]; /// Este es el que viene de el formulario Login para acceder a su cuenta
$pass=$_POST["contrasena"];
include "conexion.php";
$consulta=$conex->query("SELECT * FROM usuarios where usuario='$usuario'");
foreach ($consulta as $row) {

$nivel=$row["nivel"];
$userBD=$row["usuario"];
$passBD=$row["password"];
if(($usuario == $userBD) AND ($pass == $passBD)){
 if($nivel == "1"){
	 echo "menu 1";
  Header("Location: profesor1.html");
  }
 if($nivel == "2"){ 
 echo "menu 2";
 Header("Location: profesor.html");
 //Header("Location: index.php?mensaje=ERROR_DE_SESSION");
  }
/*
 if($nivel == "3"){
	 echo "menu 3";
//  Header("Location: paginaAlumno.php");
  }*/
}else{
Header("Location: index.php?mensaje=ERROR_DE_SESSION");
}
}
?>